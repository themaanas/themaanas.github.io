var HourColor = "ffffff";
var DateColor = "ffffff";
var MinuteColor = "ffffff";
var TwentyFourHourTime = false;
var ShowBattery = false;
var Opacity = 1.0; //From 0 to 1