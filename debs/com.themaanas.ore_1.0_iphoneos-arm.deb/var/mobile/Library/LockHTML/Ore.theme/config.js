var HoursColor = "a77a80"; // Use the format "ffffff"
var MinutesColor = "ffffff"; // Use the format "ffffff"
var DateColor = "ffffff"; // Use the format "ffffff"
var BatteryColor = "ffffff"; // Use the format "ffffff"
var ShowBattery = false; 
var ShowDate = false; 
var TwentyFourHourTime = false; 
