var BatteryGlow = true; //When charging, the battery bar can glow if you enable this.
