var WeatherColor = "ffffff"; // Use the format "ffffff"
var TimeColor = "ffffff"; // Use the format "ffffff"
var DateColor = "ffffff"; // Use the format "ffffff"
var BatteryColor = "ffffff"; // Use the format "ffffff"
var ShowWeather = true;
var ShowBattery = true;
var TwentyFourHourTime = false;
