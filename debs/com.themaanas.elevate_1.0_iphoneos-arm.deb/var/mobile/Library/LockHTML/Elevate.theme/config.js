var HourColor = "ffffff";
var DateColor = "ffffff";
var MinuteColor = "ffffff";
var TwentyFourHourTime = false;
var ShowBattery = false;
