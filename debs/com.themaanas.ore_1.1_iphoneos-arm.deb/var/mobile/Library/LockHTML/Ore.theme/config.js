var HoursColor = "ffffff"; // Use the format "ffffff"
var MinutesColor = "ffffff"; // Use the format "ffffff"
var DateColor = "ffffff"; // Use the format "ffffff"
var BatteryColor = "ffffff"; // Use the format "ffffff"
var ShowBattery = true; 
var ShowDate = true; 
var TwentyFourHourTime = false; 
var ChangeTimeToNumbers = true; 
